// SPDX-License-Identifier: Apache-2.0
//
// Audit send cost and drop accounting (plain harness, no Criterion).
//
// storm: denied creates issued back to back. Reports ns per call and how many
//        records the bounded channel dropped, for capacities 4096 and 65536.
// paced: creates issued at a fixed rate (1,000 and 10,000 per second), once
//        denied (a record is sent) and once allowed (no record), each call
//        timed on its own with a pair of clock reads; the cost of the clock
//        pair is measured separately and reported, not subtracted.
//
// Run:  cargo bench --bench audit_send

use std::ffi::CStr;
use std::hint::black_box;
use std::path::PathBuf;
use std::time::{Duration, Instant};

use vfsd_filter::filter::audit::AuditLogger;
use vfsd_filter::filter::config::{AuditDestination, AuditLevel, FilterConfig};
use vfsd_filter::filter::policy::PolicyEngine;
use vfsd_filter::filter::FilteredFs;
use virtiofsd::filesystem::{Context, DirEntry, DirectoryIterator, Extensions, FileSystem};

struct NoDir;
impl DirectoryIterator for NoDir {
    fn next(&mut self) -> Option<DirEntry<'_>> {
        None
    }
}
struct MockFs;
impl FileSystem for MockFs {
    type Inode = u64;
    type Handle = u64;
    type DirIter = NoDir;
}

fn ctx() -> Context {
    Context { uid: 1000.into(), gid: 1000.into(), pid: 4242 }
}

fn filtered(capacity: usize) -> FilteredFs<MockFs> {
    let mut cfg = FilterConfig::default();
    cfg.names.deny_suffixes = (0..10).map(|i| format!(".s{i:03}")).collect();
    cfg.names.deny_prefixes = (0..10).map(|i| format!("p{i:03}_")).collect();
    cfg.names.deny_exact = (0..10).map(|i| format!("secret{i:04}.bin")).collect();
    cfg.names.deny_suffixes.push(".pem".into());
    cfg.audit.enabled = true;
    cfg.audit.level = AuditLevel::Deny;
    cfg.audit.destination = AuditDestination::File;
    cfg.audit.path = PathBuf::from("/dev/null");
    cfg.audit.channel_capacity = capacity;
    let policy = PolicyEngine::from_config(&cfg);
    let audit = AuditLogger::new(&cfg.audit).unwrap();
    FilteredFs::new(MockFs, policy, audit)
}

fn quartiles(v: &mut [u64]) -> (u64, u64, u64, u64, u64) {
    v.sort_unstable();
    let n = v.len();
    (v[0], v[n / 4], v[n / 2], v[3 * n / 4], v[n - 1])
}

fn main() {
    let deny = CStr::from_bytes_with_nul(b"server_cert.pem\0").unwrap();
    let flags = (libc::O_CREAT | libc::O_WRONLY) as u32;

    println!("mode,capacity,rate_per_s,calls,dropped,dropped_pct,min_ns,q1_ns,median_ns,q3_ns,max_ns");

    // storm
    for cap in [4096usize, 65536] {
        let fs = filtered(cap);
        let n = 2_000_000u64;
        let t = Instant::now();
        for _ in 0..n {
            let _ = black_box(fs.create(ctx(), 7, black_box(deny), 0o644, false, flags, 0o022, Extensions::default()));
        }
        let per = t.elapsed().as_nanos() as f64 / n as f64;
        let dropped = fs.audit_dropped();
        println!("storm,{cap},unpaced,{n},{dropped},{:.2},,,{per:.1},,", 100.0 * dropped as f64 / n as f64);
    }

    // clock pair cost
    let mut clk: Vec<u64> = (0..5000)
        .map(|_| {
            let a = Instant::now();
            black_box(());
            a.elapsed().as_nanos() as u64
        })
        .collect();
    let (mn, q1, med, q3, mx) = quartiles(&mut clk);
    println!("clock_pair,,,5000,0,0.00,{mn},{q1},{med},{q3},{mx}");

    // paced: a denied create (sends a record) and an allowed create (sends none)
    let allow = CStr::from_bytes_with_nul(b"report_2026q3.md\0").unwrap();
    for (mode, name) in [("paced_deny", deny), ("paced_allow", allow)] {
    for rate in [1_000u64, 10_000] {
        let fs = filtered(4096);
        let n = 5_000usize;
        let gap = Duration::from_nanos(1_000_000_000 / rate);
        let mut samples = Vec::with_capacity(n);
        let mut next = Instant::now() + gap;
        for _ in 0..n {
            if rate <= 1_000 {
                let now = Instant::now();
                if next > now {
                    std::thread::sleep(next - now);
                }
            } else {
                while Instant::now() < next {
                    std::hint::spin_loop();
                }
            }
            next += gap;
            let a = Instant::now();
            let _ = black_box(fs.create(ctx(), 7, black_box(name), 0o644, false, flags, 0o022, Extensions::default()));
            samples.push(a.elapsed().as_nanos() as u64);
        }
        std::thread::sleep(Duration::from_millis(300));
        let dropped = fs.audit_dropped();
        let (mn, q1, med, q3, mx) = quartiles(&mut samples);
        println!("{mode},4096,{rate},{n},{dropped},{:.2},{mn},{q1},{med},{q3},{mx}", 100.0 * dropped as f64 / n as f64);
    }
    }
}
