// SPDX-License-Identifier: Apache-2.0
//
// Cost benchmarks (Criterion; every input and result passes through black_box).
//
// Group "check":     PolicyEngine::check_name_op alone, for 0, 16, 64 and 256
//                    rules per category (exact, suffix, prefix), with a name
//                    that matches no rule and a name that matches the last
//                    suffix rule. 16 byte names, 5 byte suffix and prefix
//                    rules, 14 byte exact rules.
// Group "decorated": the full FilteredFs::create path over a mock backend that
//                    returns at once, against a direct call to the same mock.
// Group "dispatch":  a FUSE_LOOKUP frame through virtiofsd's
//                    Server::handle_message over the real PassthroughFs, with
//                    and without the decorator. This is the host side cost of
//                    one forwarded request, without the virtio transport.
//
// Run:      cargo bench --bench decorator_cost
// Summary:  python3 scripts/criterion_summary.py target/criterion

use std::ffi::CStr;
use std::hint::black_box;
use std::path::{Path, PathBuf};

use criterion::{criterion_group, criterion_main, BenchmarkId, Criterion};

use vfsd_filter::filter::audit::AuditLogger;
use vfsd_filter::filter::config::{AuditDestination, AuditLevel, FilterConfig};
use vfsd_filter::filter::policy::{PolicyEngine, OP_CREATE};
use vfsd_filter::filter::FilteredFs;

use vhost_user_backend::bitmap::BitmapMmapRegion;
use virtio_queue::{desc::RawDescriptor, Queue, QueueOwnedT, QueueT};
use virtiofsd::descriptor_utils::{Reader, Writer};
use virtiofsd::filesystem::{Context, DirEntry, DirectoryIterator, Extensions, FileSystem, FsOptions};
use virtiofsd::fuse::{InHeader, OutHeader, ROOT_ID};
use virtiofsd::passthrough::{self, PassthroughFs};
use virtiofsd::server::Server;
use vm_memory::{ByteValued, Bytes, GuestAddress, GuestMemoryMmap};

const NAME_ALLOW: &[u8] = b"report_2026q3.md"; // 16 bytes, matches no rule
const PARENT: u64 = 7; // not ROOT_ID, so the first level rule is skipped

struct NoDir;
impl DirectoryIterator for NoDir {
    fn next(&mut self) -> Option<DirEntry<'_>> {
        None
    }
}

/// Backend whose every method is the trait default (returns ENOSYS at once).
struct MockFs;
impl FileSystem for MockFs {
    type Inode = u64;
    type Handle = u64;
    type DirIter = NoDir;
}

fn ctx() -> Context {
    Context { uid: 1000.into(), gid: 1000.into(), pid: 4242 }
}

/// `n` rules in each of the three categories; none matches NAME_ALLOW.
fn config_with_rules(n: usize) -> FilterConfig {
    let mut cfg = FilterConfig::default();
    cfg.names.deny_suffixes = (0..n).map(|i| format!(".s{i:03}")).collect();
    cfg.names.deny_prefixes = (0..n).map(|i| format!("p{i:03}_")).collect();
    cfg.names.deny_exact = (0..n).map(|i| format!("secret{i:04}.bin")).collect();
    cfg
}

fn bench_check(c: &mut Criterion) {
    let mut g = c.benchmark_group("check");
    for &n in &[0usize, 16, 64, 256] {
        let engine = PolicyEngine::from_config(&config_with_rules(n));
        g.bench_with_input(BenchmarkId::new("no_match", n), &n, |b, _| {
            b.iter(|| {
                black_box(engine.check_name_op(black_box(OP_CREATE), black_box(PARENT), black_box(NAME_ALLOW)))
            })
        });
        if n > 0 {
            let late = format!("report_2026.s{:03}", n - 1); // 16 bytes, last suffix rule
            let late = late.into_bytes();
            g.bench_with_input(BenchmarkId::new("late_suffix", n), &n, |b, _| {
                b.iter(|| {
                    black_box(engine.check_name_op(black_box(OP_CREATE), black_box(PARENT), black_box(&late[..])))
                })
            });
        }
    }
    g.finish();
}

fn audit_cfg(cfg: &FilterConfig, level: AuditLevel) -> FilterConfig {
    let mut cfg = cfg.clone();
    cfg.audit.enabled = level != AuditLevel::None;
    cfg.audit.level = level;
    cfg.audit.destination = AuditDestination::File;
    cfg.audit.path = PathBuf::from("/dev/null");
    cfg.audit.channel_capacity = 65536;
    cfg
}

fn decorated(cfg: &FilterConfig, level: AuditLevel) -> FilteredFs<MockFs> {
    let cfg = audit_cfg(cfg, level);
    let policy = PolicyEngine::from_config(&cfg);
    let audit = if cfg.audit.enabled { AuditLogger::new(&cfg.audit).unwrap() } else { AuditLogger::disabled() };
    FilteredFs::new(MockFs, policy, audit)
}

fn bench_decorated(c: &mut Criterion) {
    let allow = CStr::from_bytes_with_nul(b"report_2026q3.md\0").unwrap();
    let deny = CStr::from_bytes_with_nul(b"server_cert.pem\0").unwrap();
    let flags = (libc::O_CREAT | libc::O_WRONLY) as u32;

    let mut cfg = config_with_rules(10);
    cfg.names.deny_suffixes.push(".pem".into());

    let mut g = c.benchmark_group("decorated");

    g.bench_function("bare_mock_create", |b| {
        let fs = MockFs;
        b.iter(|| {
            black_box(fs.create(ctx(), black_box(PARENT), black_box(allow), 0o644, false, flags, 0o022, Extensions::default()))
        })
    });

    for (label, level) in [("audit_off", AuditLevel::None), ("audit_deny", AuditLevel::Deny), ("audit_all", AuditLevel::All)] {
        let fs = decorated(&cfg, level);
        g.bench_function(format!("allow_create_{label}"), |b| {
            b.iter(|| {
                black_box(fs.create(ctx(), black_box(PARENT), black_box(allow), 0o644, false, flags, 0o022, Extensions::default()))
            })
        });
        g.bench_function(format!("deny_create_{label}"), |b| {
            b.iter(|| {
                black_box(fs.create(ctx(), black_box(PARENT), black_box(deny), 0o644, false, flags, 0o022, Extensions::default()))
            })
        });
    }
    g.finish();
}

// ─── dispatch group ─────────────────────────────────────────────────────────

type Mem = GuestMemoryMmap<BitmapMmapRegion>;
const FUSE_LOOKUP: u32 = 1;
const VIRTQ_DESC_F_NEXT: u16 = 0x1;
const VIRTQ_DESC_F_WRITE: u16 = 0x2;
const DESC_TABLE: u64 = 0x0;
const AVAIL_RING: u64 = 0x800;
const REQ_BUF: u64 = 0x1000;
const REPLY_BUF: u64 = 0x4000;

fn backend(share: &Path) -> PassthroughFs {
    let cfg = passthrough::Config { root_dir: share.to_str().unwrap().to_owned(), ..Default::default() };
    let fs = PassthroughFs::new(cfg).expect("PassthroughFs::new");
    fs.init(FsOptions::empty()).expect("init");
    fs
}

/// Guest memory holding one LOOKUP request in a two descriptor chain.
fn lookup_memory(name: &[u8]) -> Mem {
    let mut h = InHeader::default();
    h.len = (std::mem::size_of::<InHeader>() + name.len() + 1) as u32;
    h.opcode = FUSE_LOOKUP;
    h.unique = 7;
    h.nodeid = ROOT_ID;
    h.uid = 0.into();
    h.gid = 0.into();
    h.pid = std::process::id();
    let mut req = h.as_slice().to_vec();
    req.extend_from_slice(name);
    req.push(0);

    let mem: Mem = GuestMemoryMmap::from_ranges(&[(GuestAddress(0), 0x10000)]).unwrap();
    mem.write_slice(&req, GuestAddress(REQ_BUF)).unwrap();
    let descs = [
        RawDescriptor::from(virtio_queue::desc::split::Descriptor::new(REQ_BUF, req.len() as u32, VIRTQ_DESC_F_NEXT, 1)),
        RawDescriptor::from(virtio_queue::desc::split::Descriptor::new(REPLY_BUF, 0x1000, VIRTQ_DESC_F_WRITE, 0)),
    ];
    for (i, d) in descs.iter().enumerate() {
        mem.write_obj(*d, GuestAddress(DESC_TABLE + (i as u64) * 16)).unwrap();
    }
    mem.write_obj(0u16, GuestAddress(AVAIL_RING)).unwrap();
    mem.write_obj(1u16, GuestAddress(AVAIL_RING + 2)).unwrap();
    mem.write_obj(0u16, GuestAddress(AVAIL_RING + 4)).unwrap();
    mem
}

#[inline]
fn one_request<F: FileSystem + Sync>(server: &Server<F>, mem: &Mem) -> i32 {
    let mut q = Queue::new(256).unwrap();
    q.try_set_desc_table_address(GuestAddress(DESC_TABLE)).unwrap();
    q.try_set_avail_ring_address(GuestAddress(AVAIL_RING)).unwrap();
    q.try_set_used_ring_address(GuestAddress(0x2000)).unwrap();
    q.set_size(256);
    q.set_ready(true);
    let chain = q.iter(mem).unwrap().next().expect("descriptor chain");
    let r = Reader::new(mem, chain.clone()).expect("Reader");
    let w = Writer::new(mem, chain).expect("Writer");
    server.handle_message(r, w, None::<&mut ()>).expect("handle_message");
    let out: OutHeader = mem.read_obj(GuestAddress(REPLY_BUF)).unwrap();
    out.error
}

fn bench_dispatch(c: &mut Criterion) {
    let base = std::env::temp_dir().join(format!("vfsd-bench-dispatch-{}", std::process::id()));
    let share = base.join("share");
    std::fs::create_dir_all(&share).unwrap();
    std::fs::write(share.join("report_2026q3.md"), b"x").unwrap();
    let mem = lookup_memory(NAME_ALLOW);

    let mut g = c.benchmark_group("dispatch");
    {
        let server = Server::new(backend(&share));
        assert_eq!(one_request(&server, &mem), 0);
        g.bench_function("lookup_unfiltered", |b| b.iter(|| black_box(one_request(&server, black_box(&mem)))));
    }
    for (label, rules, level) in [
        ("lookup_filtered_31_rules_audit_off", 10usize, AuditLevel::None),
        ("lookup_filtered_31_rules_audit_deny", 10, AuditLevel::Deny),
        ("lookup_filtered_768_rules_audit_deny", 256, AuditLevel::Deny),
    ] {
        let mut cfg = config_with_rules(rules);
        if rules == 10 {
            cfg.names.deny_suffixes.push(".pem".into());
        }
        let cfg = audit_cfg(&cfg, level);
        let server = Server::new(FilteredFs::from_config(backend(&share), &cfg).unwrap());
        assert_eq!(one_request(&server, &mem), 0);
        g.bench_function(label, |b| b.iter(|| black_box(one_request(&server, black_box(&mem)))));
    }
    g.finish();
    let _ = std::fs::remove_dir_all(&base);
}

criterion_group!(benches, bench_check, bench_decorated, bench_dispatch);
criterion_main!(benches);
