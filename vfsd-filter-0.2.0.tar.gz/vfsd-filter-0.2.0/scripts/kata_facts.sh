#!/usr/bin/env bash
# Records the Kata facts the reviewers asked for. Run on the Kata host while a
# Kata container is up. Output goes to kata_facts.txt.
set -u
CID="${1:?usage: kata_facts.sh <container-id-or-name>}"
{
  echo "== date";            date -Iseconds
  echo "== host";            uname -a; grep -m1 "model name" /proc/cpuinfo
  echo "== kata version";    kata-runtime --version 2>/dev/null || true
  echo "== runtime in use";  grep -E '^\s*(runtime_type|ConfigPath|shared_fs|virtio_fs_daemon|virtio_fs_cache|virtio_fs_extra_args|virtio_fs_cache_size)' \
                               /etc/kata-containers/*.toml /opt/kata/share/defaults/kata-containers/*.toml 2>/dev/null
  echo "== virtiofsd command lines (sandbox and seccomp flags)"
  ps -eo pid,user,args | grep -E '[v]irtiofsd'
  echo "== guest mounts (cache mode, dax)"
  sudo ctr -n k8s.io task exec --exec-id facts "$CID" sh -c 'cat /proc/mounts | grep -E "virtiofs|kataShared"' 2>/dev/null \
    || docker exec "$CID" sh -c 'cat /proc/mounts | grep -E "virtiofs|kataShared"' 2>/dev/null \
    || nerdctl exec "$CID" sh -c 'cat /proc/mounts | grep -E "virtiofs|kataShared"'
} | tee kata_facts.txt
