#!/usr/bin/env bash
# Single harness for every end to end workload. Run INSIDE the Kata guest on
# the virtio-fs mount. Every workload runs in one long lived bash process
# (no fork/exec per file), caches are dropped on the host between trials by
# the host side wrapper, and the workload order is shuffled per trial.
# Output: CSV rows  config,trial,workload,seconds
set -euo pipefail
DIR="${1:?usage: run_fs_bench.sh <dir-on-virtiofs> <config-label> <trials>}"
CFG="${2:?}"; TRIALS="${3:-5}"
N=1000; MIB=256
now() { date +%s.%N; }
w_create() { for i in $(seq 1 $N); do printf "%064d" 0 > "$DIR/f$i"; done; }   # builtin, no fork
w_read()   { for i in $(seq 1 $N); do read -r _ < "$DIR/f$i" || true; done; }   # builtin, no fork
w_delete() { find "$DIR" -maxdepth 1 -name "f*" -type f -delete; }   # one process, N unlinks
w_seqw()   { dd if=/dev/zero of="$DIR/big" bs=1M count=$MIB conv=fsync status=none; }
w_seqr()   { dd if="$DIR/big" of=/dev/null bs=1M status=none; }
for t in $(seq 1 "$TRIALS"); do
  rm -f "$DIR"/f* "$DIR/big"; sync
  # create must precede read and delete; seq write must precede seq read
  for pair in $(printf '%s\n' "meta" "bulk" | shuf); do
    if [ "$pair" = meta ]; then order="create read delete"; else order="seqw seqr"; fi
    for w in $order; do
      s=$(now); "w_$w"; e=$(now)
      echo "$CFG,$t,$w,$(awk -v a="$s" -v b="$e" 'BEGIN{printf "%.6f", b-a}')"
      [ -f /proc/sys/vm/drop_caches ] && { sync; echo 3 > /proc/sys/vm/drop_caches; } 2>/dev/null || true
    done
  done
done
