#!/usr/bin/env python3
"""Per iteration min, median, IQR and max (ns) from Criterion sample.json files.

Usage: python3 scripts/criterion_summary.py target/criterion > bench_summary.csv
"""
import json, pathlib, statistics, sys

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "target/criterion")
print("benchmark,samples,min_ns,q1_ns,median_ns,q3_ns,iqr_ns,max_ns")
for f in sorted(root.glob("**/new/sample.json")):
    d = json.loads(f.read_text())
    per = sorted(t / i for t, i in zip(d["times"], d["iters"]))
    q1, med, q3 = statistics.quantiles(per, n=4, method="inclusive")
    name = "/".join(f.relative_to(root).parts[:-2])
    print(f"{name},{len(per)},{per[0]:.2f},{q1:.2f},{med:.2f},{q3:.2f},{q3-q1:.2f},{per[-1]:.2f}")
