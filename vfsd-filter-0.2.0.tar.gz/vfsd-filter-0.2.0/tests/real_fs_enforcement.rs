// SPDX-License-Identifier: Apache-2.0
//
// Real filesystem enforcement tests.
//
// Every test here drives the stock virtiofsd 1.14.0 `PassthroughFs` backend
// (rev c2540f8) over a real temporary directory, once unfiltered and once
// wrapped in `FilteredFs`. The backend runs in process, so no virtiofsd
// sandbox (namespace or chroot) and no seccomp filter is active. This is the
// same configuration that Kata runtime-rs <= 3.30.0 used when it launched
// virtiofsd with `--sandbox none --seccomp none` (CVE-2026-47243).
//
// Each denial test checks three things:
//   1. the call returns the expected errno,
//   2. the audit record names the rule that fired (its reason string),
//   3. the host directory has no artifact afterwards.
//
// Run with:  cargo test --test real_fs_enforcement -- --test-threads=1 --nocapture

use std::ffi::CString;
use std::fs;
use std::io;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

use vfsd_filter::filter::config::{AuditDestination, AuditLevel, FilterConfig};
use vfsd_filter::filter::policy::{PolicyEngine, Verdict};
use vfsd_filter::filter::FilteredFs;

use virtiofsd::filesystem::{Context, Extensions, FileSystem, FsOptions, SetattrValid};
use virtiofsd::fuse::{SetattrIn, ROOT_ID};
use virtiofsd::passthrough::{self, PassthroughFs};

// ─── Fixtures ────────────────────────────────────────────────────────────────

/// A scratch area with a shared directory (the export) and a sibling
/// directory standing in for the rest of the host.
struct Scratch {
    base: PathBuf,
    share: PathBuf,
    outside: PathBuf,
}

impl Scratch {
    fn new(tag: &str) -> Self {
        let base = std::env::temp_dir().join(format!(
            "vfsd-filter-{}-{}-{}",
            tag,
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let share = base.join("share");
        let outside = base.join("outside");
        fs::create_dir_all(&share).unwrap();
        fs::create_dir_all(&outside).unwrap();
        Scratch { base, share, outside }
    }
}

impl Drop for Scratch {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.base);
    }
}

fn ctx() -> Context {
    // uid/gid 0 makes PassthroughFs skip credential switching, so the test
    // runs unprivileged and still exercises the real syscalls.
    Context { uid: 0.into(), gid: 0.into(), pid: std::process::id() as i32 }
}

fn backend(share: &Path) -> PassthroughFs {
    let cfg = passthrough::Config {
        root_dir: share.to_str().unwrap().to_owned(),
        ..Default::default()
    };
    let fs = PassthroughFs::new(cfg).expect("PassthroughFs::new");
    fs.init(FsOptions::empty()).expect("PassthroughFs::init");
    fs
}

fn filtered(share: &Path, cfg: &mut FilterConfig, audit_path: &Path) -> FilteredFs<PassthroughFs> {
    cfg.audit.enabled = true;
    cfg.audit.destination = AuditDestination::File;
    cfg.audit.level = AuditLevel::All;
    cfg.audit.path = audit_path.to_path_buf();
    FilteredFs::from_config(backend(share), cfg).expect("FilteredFs::from_config")
}

fn cstr(s: &str) -> CString {
    CString::new(s).unwrap()
}

/// Wait for the background audit writer to flush (it flushes every 200 ms
/// and on channel close) and return the record for `op`.
fn audit_record(path: &Path, op: &str) -> String {
    let deadline = Instant::now() + Duration::from_secs(3);
    loop {
        if let Ok(text) = fs::read_to_string(path) {
            if let Some(line) = text.lines().find(|l| l.contains(&format!("\"op\":\"{op}\""))) {
                return line.to_owned();
            }
        }
        assert!(Instant::now() < deadline, "no audit record for op {op} in {path:?}");
        std::thread::sleep(Duration::from_millis(50));
    }
}

fn reason_of(v: Verdict) -> &'static str {
    match v {
        Verdict::Deny { reason, .. } => reason,
        Verdict::Allow => "allow",
    }
}

/// Entry and Attr do not implement Debug, so Result::expect_err is unavailable.
fn denied<T>(r: io::Result<T>, what: &str) -> io::Error {
    match r {
        Ok(_) => panic!("{what}: call succeeded"),
        Err(e) => e,
    }
}

fn exists_no_follow(p: &Path) -> bool {
    fs::symlink_metadata(p).is_ok()
}

// ─── 1. CVE-2026-47243 primitive: absolute name in FUSE_SYMLINK ─────────────

#[test]
fn cve_absolute_symlink_name_escapes_unfiltered_and_is_denied_filtered() {
    let s = Scratch::new("cve");
    let canary = s.outside.join("cron-canary");
    let canary_name = cstr(canary.to_str().unwrap());
    let target = cstr("payload");

    // Unfiltered: virtiofsd 1.14.0 forwards the name straight to
    // symlinkat(target, parent_fd, name). An absolute name makes the kernel
    // ignore parent_fd, so the link lands outside the share. (The follow up
    // lookup inside PassthroughFs may or may not succeed; the side effect on
    // the host is what matters, so only the canary is asserted.)
    let plain = backend(&s.share);
    let r = plain.symlink(ctx(), &target, ROOT_ID, &canary_name, Extensions::default());
    println!("unfiltered symlink -> {:?}", r.as_ref().map(|e| e.inode));
    assert!(exists_no_follow(&canary), "canary must exist outside the share");
    assert_eq!(fs::read_link(&canary).unwrap(), PathBuf::from("payload"));
    fs::remove_file(&canary).unwrap();

    // Filtered: same request, same backend.
    let audit = s.base.join("audit.jsonl");
    let mut cfg = FilterConfig::default();
    let ffs = filtered(&s.share, &mut cfg, &audit);
    let r = ffs.symlink(ctx(), &target, ROOT_ID, &canary_name, Extensions::default());
    let err = denied(r, "filtered symlink must be denied");
    assert_eq!(err.raw_os_error(), Some(libc::EINVAL));
    assert!(!exists_no_follow(&canary), "no artifact outside the share");
    drop(ffs);

    let rec = audit_record(&audit, "symlink");
    println!("audit: {rec}");
    assert!(rec.contains("\"decision\":\"deny\""));
    assert!(rec.contains("name contains '/' separator byte"), "rule fired: Eq. (3)");
}

// ─── 2. Eq. (5): magic link target /proc/<pid>/root ──────────────────────────

#[test]
fn proc_pid_root_target_is_denied_by_target_rule() {
    let s = Scratch::new("procroot");
    let link = s.share.join("procroot-link");
    let target_s = format!("/proc/{}/root", std::process::id());
    let target = cstr(&target_s);
    let name = cstr("procroot-link");

    // Unfiltered: the link is created inside the share, but any host process
    // that later follows it (backup agent, scanner, indexer) resolves to the
    // host root filesystem of that pid.
    let plain = backend(&s.share);
    plain
        .symlink(ctx(), &target, ROOT_ID, &name, Extensions::default())
        .expect("unfiltered backend accepts the magic link target");
    assert!(exists_no_follow(&link));
    let resolved = fs::canonicalize(&link).unwrap();
    println!("unfiltered: {link:?} -> host resolves to {resolved:?}");
    assert!(!resolved.starts_with(&s.share), "host side resolution leaves the share");
    fs::remove_file(&link).unwrap();
    drop(plain);

    // Filtered with allow_absolute_targets = false.
    let audit = s.base.join("audit.jsonl");
    let mut cfg = FilterConfig::default();
    cfg.symlink.allow_absolute_targets = false;
    cfg.symlink.allow_dotdot_targets = false;
    let engine = PolicyEngine::from_config(&cfg);
    assert_eq!(
        reason_of(engine.check_symlink(ROOT_ID, b"procroot-link", target_s.as_bytes())),
        "absolute symlink target denied by policy"
    );
    let ffs = filtered(&s.share, &mut cfg, &audit);
    let err = denied(
        ffs
        .symlink(ctx(), &target, ROOT_ID, &name, Extensions::default()),
        "magic link target must be denied",
    );
    assert_eq!(err.raw_os_error(), Some(libc::EPERM));
    assert!(!exists_no_follow(&link));
    drop(ffs);
    let rec = audit_record(&audit, "symlink");
    println!("audit: {rec}");
    assert!(rec.contains("absolute symlink target denied by policy"));
}

#[test]
fn relative_dotdot_proc_root_target_is_denied_by_target_rule() {
    let s = Scratch::new("dotdot");
    let audit = s.base.join("audit.jsonl");
    let mut cfg = FilterConfig::default();
    cfg.symlink.allow_absolute_targets = false;
    cfg.symlink.allow_dotdot_targets = false;
    let ffs = filtered(&s.share, &mut cfg, &audit);
    let target = cstr("../../../../../../proc/1/root");
    let name = cstr("rel-link");
    let err = denied(
        ffs
        .symlink(ctx(), &target, ROOT_ID, &name, Extensions::default()),
        "dotdot target must be denied",
    );
    assert_eq!(err.raw_os_error(), Some(libc::EPERM));
    assert!(!exists_no_follow(&s.share.join("rel-link")));
    drop(ffs);
    let rec = audit_record(&audit, "symlink");
    println!("audit: {rec}");
    assert!(rec.contains("symlink target with '..' component denied by policy"));
}

// ─── 3. Eq. (4): name deny list on a real create ────────────────────────────

#[test]
fn suffix_rule_blocks_real_create() {
    let s = Scratch::new("suffix");
    let audit = s.base.join("audit.jsonl");
    let mut cfg = FilterConfig::default();
    cfg.names.deny_suffixes = vec![".pem".into()];
    let ffs = filtered(&s.share, &mut cfg, &audit);
    let name = cstr("server.pem");
    let flags = (libc::O_CREAT | libc::O_WRONLY) as u32;
    let err = denied(
        ffs
        .create(ctx(), ROOT_ID, &name, 0o600, false, flags, 0o022, Extensions::default()),
        "suffix rule must deny",
    );
    assert_eq!(err.raw_os_error(), Some(libc::EACCES));
    assert!(!exists_no_follow(&s.share.join("server.pem")));
    drop(ffs);
    let rec = audit_record(&audit, "create");
    println!("audit: {rec}");
    assert!(rec.contains("name denied by suffix rule"));
}

// ─── 4. Non zero M_flag: O_TRUNC on create ──────────────────────────────────

#[test]
fn open_flag_rule_blocks_truncating_create_and_preserves_content() {
    let s = Scratch::new("trunc");
    let victim = s.share.join("ledger.db");
    fs::write(&victim, b"committed rows").unwrap();

    let audit = s.base.join("audit.jsonl");
    let mut cfg = FilterConfig::default();
    cfg.operations.open_flags.deny_trunc = true;
    let ffs = filtered(&s.share, &mut cfg, &audit);
    let name = cstr("ledger.db");
    let flags = (libc::O_CREAT | libc::O_WRONLY | libc::O_TRUNC) as u32;
    let err = denied(
        ffs
        .create(ctx(), ROOT_ID, &name, 0o644, false, flags, 0o022, Extensions::default()),
        "O_TRUNC must be denied",
    );
    assert_eq!(err.raw_os_error(), Some(libc::EACCES));
    assert_eq!(fs::read(&victim).unwrap(), b"committed rows", "content not truncated");
    drop(ffs);
    let rec = audit_record(&audit, "create");
    println!("audit: {rec}");
    assert!(rec.contains("open flags denied by policy"));
}

// ─── 5. Non zero M_set: chmod via setattr ───────────────────────────────────

#[test]
fn setattr_rule_blocks_chmod_and_preserves_mode() {
    let s = Scratch::new("chmod");
    let file = s.share.join("tool.sh");
    fs::write(&file, b"#!/bin/sh\n").unwrap();
    fs::set_permissions(&file, fs::Permissions::from_mode(0o644)).unwrap();

    let audit = s.base.join("audit.jsonl");
    let mut cfg = FilterConfig::default();
    cfg.operations.setattr.allow_chmod = false;
    let ffs = filtered(&s.share, &mut cfg, &audit);

    let entry = ffs.lookup(ctx(), ROOT_ID, &cstr("tool.sh")).expect("lookup");
    let attr = SetattrIn { valid: SetattrValid::MODE.bits(), mode: 0o4755, ..Default::default() };
    let err = denied(
        ffs
        .setattr(ctx(), entry.inode, attr, None, SetattrValid::MODE),
        "chmod must be denied",
    );
    assert_eq!(err.raw_os_error(), Some(libc::EPERM));
    let mode = fs::metadata(&file).unwrap().permissions().mode() & 0o7777;
    assert_eq!(mode, 0o644, "setuid bit not applied");
    drop(ffs);
    let rec = audit_record(&audit, "setattr");
    println!("audit: {rec}");
    assert!(rec.contains("setattr sub-operation denied by policy"));
}

// ─── 6. Legitimate traffic still passes on the same configuration ───────────

#[test]
fn legitimate_operations_pass_under_full_policy() {
    let s = Scratch::new("legit");
    let audit = s.base.join("audit.jsonl");
    let mut cfg = FilterConfig::default();
    cfg.names.deny_suffixes = vec![".pem".into()];
    cfg.symlink.allow_absolute_targets = false;
    cfg.symlink.allow_dotdot_targets = false;
    cfg.operations.open_flags.deny_trunc = true;
    cfg.operations.setattr.allow_chmod = false;
    let ffs = filtered(&s.share, &mut cfg, &audit);

    let flags = (libc::O_CREAT | libc::O_WRONLY) as u32;
    ffs.create(ctx(), ROOT_ID, &cstr("report.txt"), 0o644, false, flags, 0o022, Extensions::default())
        .expect("ordinary create passes");
    ffs.symlink(ctx(), &cstr("report.txt"), ROOT_ID, &cstr("latest"), Extensions::default())
        .expect("relative in share symlink passes");
    assert!(s.share.join("report.txt").exists());
    assert_eq!(fs::read_link(s.share.join("latest")).unwrap(), PathBuf::from("report.txt"));
    drop(ffs);
    let rec = audit_record(&audit, "symlink");
    assert!(rec.contains("\"decision\":\"allow\""));
}
