// SPDX-License-Identifier: Apache-2.0
//
// Raw FUSE frames through virtiofsd's own dispatcher.
//
// Each test hand builds a FUSE request (InHeader followed by the opcode's
// payload) in an in memory virtqueue descriptor chain and passes it to
// virtiofsd::server::Server::handle_message, the same entry point the
// vhost-user worker calls for a guest request. The server decodes the frame
// and dispatches the trait call, once over a bare PassthroughFs and once over
// FilteredFs<PassthroughFs>. No guest kernel is involved, so the guest side
// validation that a normal FUSE client would apply is bypassed, as in the
// CVE-2026-47243 attack. The backend runs in process with no sandbox.
//
// Run with:  cargo test --test server_dispatch -- --test-threads=1 --nocapture

use std::fs;
use std::path::{Path, PathBuf};

use vfsd_filter::filter::config::FilterConfig;
use vfsd_filter::filter::FilteredFs;

use vhost_user_backend::bitmap::BitmapMmapRegion;
use virtio_queue::{desc::RawDescriptor, Queue, QueueOwnedT, QueueT};
use virtiofsd::descriptor_utils::{Reader, Writer};
use virtiofsd::filesystem::{FileSystem, FsOptions};
use virtiofsd::fuse::{InHeader, OutHeader, ROOT_ID};
use virtiofsd::passthrough::{self, PassthroughFs};
use virtiofsd::server::Server;
use vm_memory::{ByteValued, Bytes, GuestAddress, GuestMemoryMmap};

type Mem = GuestMemoryMmap<BitmapMmapRegion>;

const FUSE_LOOKUP: u32 = 1;
const FUSE_SYMLINK: u32 = 6;
const VIRTQ_DESC_F_NEXT: u16 = 0x1;
const VIRTQ_DESC_F_WRITE: u16 = 0x2;
const DESC_TABLE: u64 = 0x0;
const AVAIL_RING: u64 = 0x800;
const REQ_BUF: u64 = 0x1000;
const REPLY_BUF: u64 = 0x4000;
const REPLY_LEN: u32 = 0x1000;

struct Scratch {
    base: PathBuf,
    share: PathBuf,
    outside: PathBuf,
}

impl Scratch {
    fn new(tag: &str) -> Self {
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let base = std::env::temp_dir().join(format!("vfsd-dispatch-{tag}-{}-{nanos}", std::process::id()));
        let share = base.join("share");
        let outside = base.join("outside");
        fs::create_dir_all(&share).unwrap();
        fs::create_dir_all(&outside).unwrap();
        Scratch { base, share, outside }
    }
}

impl Drop for Scratch {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.base);
    }
}

fn backend(share: &Path) -> PassthroughFs {
    let cfg = passthrough::Config { root_dir: share.to_str().unwrap().to_owned(), ..Default::default() };
    let fs = PassthroughFs::new(cfg).expect("PassthroughFs::new");
    fs.init(FsOptions::empty()).expect("init");
    fs
}

fn filtered(share: &Path, cfg: FilterConfig) -> FilteredFs<PassthroughFs> {
    let mut cfg = cfg;
    cfg.audit.enabled = false;
    FilteredFs::from_config(backend(share), &cfg).expect("FilteredFs::from_config")
}

/// Builds one FUSE request frame: InHeader followed by `payload`.
fn frame(opcode: u32, nodeid: u64, payload: &[u8]) -> Vec<u8> {
    let len = (std::mem::size_of::<InHeader>() + payload.len()) as u32;
    let mut h = InHeader::default();
    h.len = len;
    h.opcode = opcode;
    h.unique = 7;
    h.nodeid = nodeid;
    h.uid = 0.into();
    h.gid = 0.into();
    h.pid = std::process::id();
    let mut v = h.as_slice().to_vec();
    v.extend_from_slice(payload);
    v
}

/// Puts the request in a two descriptor chain (readable request, writable
/// reply), runs it through Server::handle_message and returns the FUSE error
/// field of the reply (0 on success, a negative errno on failure).
fn dispatch_full<F: FileSystem + Sync>(server: &Server<F>, request: &[u8]) -> (i32, Vec<u8>) {
    let mem: Mem = GuestMemoryMmap::from_ranges(&[(GuestAddress(0), 0x10000)]).unwrap();
    mem.write_slice(request, GuestAddress(REQ_BUF)).unwrap();

    let descs = [
        RawDescriptor::from(virtio_queue::desc::split::Descriptor::new(
            REQ_BUF, request.len() as u32, VIRTQ_DESC_F_NEXT, 1,
        )),
        RawDescriptor::from(virtio_queue::desc::split::Descriptor::new(
            REPLY_BUF, REPLY_LEN, VIRTQ_DESC_F_WRITE, 0,
        )),
    ];
    for (i, d) in descs.iter().enumerate() {
        mem.write_obj(*d, GuestAddress(DESC_TABLE + (i as u64) * 16)).unwrap();
    }
    // avail ring: flags = 0, idx = 1, ring[0] = descriptor 0
    mem.write_obj(0u16, GuestAddress(AVAIL_RING)).unwrap();
    mem.write_obj(1u16, GuestAddress(AVAIL_RING + 2)).unwrap();
    mem.write_obj(0u16, GuestAddress(AVAIL_RING + 4)).unwrap();

    let mut q = Queue::new(256).unwrap();
    q.try_set_desc_table_address(GuestAddress(DESC_TABLE)).unwrap();
    q.try_set_avail_ring_address(GuestAddress(AVAIL_RING)).unwrap();
    q.try_set_used_ring_address(GuestAddress(0x2000)).unwrap();
    q.set_size(256);
    q.set_ready(true);
    let chain = q.iter(&mem).unwrap().next().expect("descriptor chain");

    let r = Reader::new(&mem, chain.clone()).expect("Reader");
    let w = Writer::new(&mem, chain).expect("Writer");
    server.handle_message(r, w, None::<&mut ()>).expect("handle_message");

    let out: OutHeader = mem.read_obj(GuestAddress(REPLY_BUF)).unwrap();
    let mut body = vec![0u8; 256];
    mem.read_slice(&mut body, GuestAddress(REPLY_BUF + std::mem::size_of::<OutHeader>() as u64)).unwrap();
    (out.error, body)
}

fn dispatch<F: FileSystem + Sync>(server: &Server<F>, request: &[u8]) -> i32 {
    dispatch_full(server, request).0
}

fn symlink_payload(name: &str, target: &str) -> Vec<u8> {
    let mut p = name.as_bytes().to_vec();
    p.push(0);
    p.extend_from_slice(target.as_bytes());
    p.push(0);
    p
}

fn lookup_payload(name: &str) -> Vec<u8> {
    let mut p = name.as_bytes().to_vec();
    p.push(0);
    p
}

fn exists_no_follow(p: &Path) -> bool {
    fs::symlink_metadata(p).is_ok()
}

#[test]
fn raw_fuse_symlink_absolute_name_escapes_unfiltered_and_is_denied_filtered() {
    let s = Scratch::new("raw-cve");
    let canary = s.outside.join("cron-canary");
    let req = frame(FUSE_SYMLINK, ROOT_ID, &symlink_payload(canary.to_str().unwrap(), "payload"));

    let plain = Server::new(backend(&s.share));
    let err = dispatch(&plain, &req);
    println!("unfiltered: reply error {err}, canary outside share exists = {}", exists_no_follow(&canary));
    assert!(exists_no_follow(&canary), "unfiltered dispatch must create the canary outside the share");
    fs::remove_file(&canary).unwrap();

    let guarded = Server::new(filtered(&s.share, FilterConfig::default()));
    let err = dispatch(&guarded, &req);
    println!("filtered:   reply error {err}, canary outside share exists = {}", exists_no_follow(&canary));
    assert_eq!(err, -libc::EINVAL);
    assert!(!exists_no_follow(&canary));
}

#[test]
fn raw_fuse_symlink_relative_name_in_share_passes_filtered() {
    let s = Scratch::new("raw-ok");
    let req = frame(FUSE_SYMLINK, ROOT_ID, &symlink_payload("latest", "report.txt"));
    let guarded = Server::new(filtered(&s.share, FilterConfig::default()));
    let err = dispatch(&guarded, &req);
    println!("filtered relative symlink: reply error {err}");
    assert_eq!(err, 0);
    assert_eq!(fs::read_link(s.share.join("latest")).unwrap(), PathBuf::from("report.txt"));
}

#[test]
fn raw_fuse_lookup_dot_and_dotdot_pass_but_creating_them_is_denied() {
    let s = Scratch::new("dots");
    fs::create_dir(s.share.join("sub")).unwrap();
    for name in [".", ".."] {
        let req = frame(FUSE_LOOKUP, ROOT_ID, &lookup_payload(name));
        let plain = Server::new(backend(&s.share));
        let guarded = Server::new(filtered(&s.share, FilterConfig::default()));
        let e_plain = dispatch(&plain, &req);
        let e_filt = dispatch(&guarded, &req);
        println!("LOOKUP {name:>2} at root: unfiltered reply {e_plain}, filtered reply {e_filt}");
        assert_eq!(e_filt, e_plain, "lookup of {name} must behave as the unfiltered server");
        assert_eq!(e_filt, 0);

        let guarded = Server::new(filtered(&s.share, FilterConfig::default()));
        let mk = frame(FUSE_MKDIR, ROOT_ID, &mkdir_payload(name));
        let e = dispatch(&guarded, &mk);
        println!("MKDIR  {name:>2} at root: filtered reply {e}");
        assert_eq!(e, -libc::EINVAL);
        let sl = frame(FUSE_SYMLINK, ROOT_ID, &symlink_payload(name, "x"));
        let e = dispatch(&guarded, &sl);
        println!("SYMLINK {name:>2} at root: filtered reply {e}");
        assert_eq!(e, -libc::EINVAL);
    }
}

// ─── Predefined raw payload set ──────────────────────────────────────────────
//
// Twelve FUSE frames whose NAME field is hostile: an absolute host path or a
// relative path with a traversal component, across eight opcodes. The set is
// fixed here in version control. Each frame is sent to a fresh unfiltered
// server and a fresh filtered server; the test records whether the request
// had an effect outside the shared directory.

const FUSE_MKNOD: u32 = 8;
const FUSE_MKDIR: u32 = 9;
const FUSE_UNLINK: u32 = 10;
const FUSE_RMDIR: u32 = 11;
const FUSE_RENAME: u32 = 12;
const FUSE_LINK: u32 = 13;
const FUSE_CREATE: u32 = 35;

fn le32(v: u32) -> [u8; 4] { v.to_le_bytes() }
fn le64(v: u64) -> [u8; 8] { v.to_le_bytes() }
fn cname(name: &str) -> Vec<u8> { let mut p = name.as_bytes().to_vec(); p.push(0); p }

fn mkdir_payload(name: &str) -> Vec<u8> {
    let mut p = Vec::new(); p.extend(le32(0o755)); p.extend(le32(0o022)); p.extend(cname(name)); p
}
fn mknod_payload(name: &str) -> Vec<u8> {
    let mut p = Vec::new();
    p.extend(le32(libc::S_IFREG | 0o644)); p.extend(le32(0)); p.extend(le32(0o022)); p.extend(le32(0));
    p.extend(cname(name)); p
}
fn create_payload(name: &str) -> Vec<u8> {
    let mut p = Vec::new();
    p.extend(le32((libc::O_CREAT | libc::O_WRONLY) as u32)); p.extend(le32(0o644)); p.extend(le32(0o022)); p.extend(le32(0));
    p.extend(cname(name)); p
}
fn link_payload(old_nodeid: u64, newname: &str) -> Vec<u8> {
    let mut p = Vec::new(); p.extend(le64(old_nodeid)); p.extend(cname(newname)); p
}
fn rename_payload(newdir: u64, old: &str, new: &str) -> Vec<u8> {
    let mut p = Vec::new(); p.extend(le64(newdir)); p.extend(cname(old)); p.extend(cname(new)); p
}

#[derive(Clone, Copy)]
enum Effect { Appears, Vanishes, LookupSucceeds }

struct Payload {
    id: &'static str,
    opcode: &'static str,
    name_form: &'static str,
    /// Path relative to the scratch "outside" directory that the frame targets.
    outside_rel: &'static str,
    effect: Effect,
}

const PAYLOADS: &[Payload] = &[
    Payload { id: "P01", opcode: "SYMLINK", name_form: "absolute",  outside_rel: "p01-link",    effect: Effect::Appears },
    Payload { id: "P02", opcode: "MKDIR",   name_form: "absolute",  outside_rel: "p02-dir",     effect: Effect::Appears },
    Payload { id: "P03", opcode: "MKNOD",   name_form: "absolute",  outside_rel: "p03-node",    effect: Effect::Appears },
    Payload { id: "P04", opcode: "CREATE",  name_form: "absolute",  outside_rel: "p04-file",    effect: Effect::Appears },
    Payload { id: "P05", opcode: "LINK",    name_form: "absolute",  outside_rel: "p05-hard",    effect: Effect::Appears },
    Payload { id: "P06", opcode: "RENAME",  name_form: "absolute",  outside_rel: "p06-moved",   effect: Effect::Appears },
    Payload { id: "P07", opcode: "UNLINK",  name_form: "absolute",  outside_rel: "victim-file", effect: Effect::Vanishes },
    Payload { id: "P08", opcode: "RMDIR",   name_form: "absolute",  outside_rel: "victim-dir",  effect: Effect::Vanishes },
    Payload { id: "P09", opcode: "SYMLINK", name_form: "traversal", outside_rel: "p09-link",    effect: Effect::Appears },
    Payload { id: "P10", opcode: "MKDIR",   name_form: "traversal", outside_rel: "p10-dir",     effect: Effect::Appears },
    Payload { id: "P11", opcode: "UNLINK",  name_form: "traversal", outside_rel: "victim-file", effect: Effect::Vanishes },
    Payload { id: "P12", opcode: "LOOKUP",  name_form: "absolute",  outside_rel: "victim-file", effect: Effect::LookupSucceeds },
];

/// Sends one payload to `server` over a fresh scratch area and reports
/// (reply error, effect outside the share happened).
fn run_payload<F: FileSystem + Sync>(p: &Payload, s: &Scratch, server: &Server<F>) -> (i32, bool) {
    fs::write(s.outside.join("victim-file"), b"host data").unwrap();
    fs::create_dir(s.outside.join("victim-dir")).unwrap();
    fs::write(s.share.join("inside.txt"), b"guest data").unwrap();
    fs::write(s.share.join("mv.txt"), b"guest data").unwrap();

    let target = s.outside.join(p.outside_rel);
    let name = match p.name_form {
        "absolute" => target.to_str().unwrap().to_owned(),
        _ => format!("../outside/{}", p.outside_rel),
    };
    let req = match p.opcode {
        "SYMLINK" => frame(FUSE_SYMLINK, ROOT_ID, &symlink_payload(&name, "payload")),
        "MKDIR" => frame(FUSE_MKDIR, ROOT_ID, &mkdir_payload(&name)),
        "MKNOD" => frame(FUSE_MKNOD, ROOT_ID, &mknod_payload(&name)),
        "CREATE" => frame(FUSE_CREATE, ROOT_ID, &create_payload(&name)),
        "LINK" => {
            let (e, body) = dispatch_full(server, &frame(FUSE_LOOKUP, ROOT_ID, &lookup_payload("inside.txt")));
            assert_eq!(e, 0, "setup lookup of inside.txt");
            let nodeid = u64::from_le_bytes(body[0..8].try_into().unwrap());
            frame(FUSE_LINK, ROOT_ID, &link_payload(nodeid, &name))
        }
        "RENAME" => frame(FUSE_RENAME, ROOT_ID, &rename_payload(ROOT_ID, "mv.txt", &name)),
        "UNLINK" => frame(FUSE_UNLINK, ROOT_ID, &lookup_payload(&name)),
        "RMDIR" => frame(FUSE_RMDIR, ROOT_ID, &lookup_payload(&name)),
        "LOOKUP" => frame(FUSE_LOOKUP, ROOT_ID, &lookup_payload(&name)),
        other => panic!("unknown opcode {other}"),
    };
    let err = dispatch(server, &req);
    let happened = match p.effect {
        Effect::Appears => exists_no_follow(&target),
        Effect::Vanishes => !exists_no_follow(&target),
        Effect::LookupSucceeds => err == 0,
    };
    (err, happened)
}

#[test]
fn predefined_raw_payload_set() {
    let mut escaped_unfiltered = 0;
    let mut denied_filtered = 0;
    println!("PAYLOAD|opcode|name form|unfiltered reply|unfiltered effect outside share|filtered reply|filtered effect outside share");
    for p in PAYLOADS {
        let s1 = Scratch::new(p.id);
        let plain = Server::new(backend(&s1.share));
        let (e_plain, eff_plain) = run_payload(p, &s1, &plain);

        let s2 = Scratch::new(p.id);
        let guarded = Server::new(filtered(&s2.share, FilterConfig::default()));
        let (e_filt, eff_filt) = run_payload(p, &s2, &guarded);

        println!("{}|{}|{}|{}|{}|{}|{}", p.id, p.opcode, p.name_form, e_plain,
                 if eff_plain { "YES" } else { "no" }, e_filt, if eff_filt { "YES" } else { "no" });
        if eff_plain { escaped_unfiltered += 1; }
        if e_filt == -libc::EINVAL && !eff_filt { denied_filtered += 1; }
        assert_eq!(e_filt, -libc::EINVAL, "{}: filtered reply", p.id);
        assert!(!eff_filt, "{}: no effect outside the share with the filter", p.id);
    }
    println!("SUMMARY unfiltered_effect_outside_share={}/{} filtered_denied_no_effect={}/{}",
             escaped_unfiltered, PAYLOADS.len(), denied_filtered, PAYLOADS.len());
}
