// SPDX-License-Identifier: Apache-2.0
// virtiofsd V1 host-side request-validation filter — audit logger

use virtiofsd::soft_idmap::Id;
use std::fs::OpenOptions;
use std::io::{BufWriter, Write};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::mpsc::{sync_channel, Receiver, SyncSender, TrySendError};
use std::sync::Arc;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use crate::filter::config::{AuditConfig, AuditDestination, AuditLevel};
use crate::filter::policy::Verdict;
use virtiofsd::filesystem::Context;

/// Classification of the filesystem operation for the audit record.
#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OpKind {
    Lookup = 0,
    Create = 1,
    Mkdir = 2,
    Unlink = 3,
    Rmdir = 4,
    Rename = 5,
    Symlink = 6,
    Link = 7,
    Mknod = 8,
    Open = 9,
    Read = 10,
    Write = 11,
    Setattr = 12,
    Fallocate = 13,
    Opendir = 14,
    Readlink = 15,
    Setxattr = 16,
    Getxattr = 17,
    Listxattr = 18,
    Removexattr = 19,
    Copyfilerange = 20,
    Syncfs = 21,
    Fsync = 22,
    Fsyncdir = 23,
    Tmpfile = 24,
    Readdir = 25,
    Other = 255,
}

impl OpKind {
    pub fn as_str(self) -> &'static str {
        match self {
            OpKind::Lookup => "lookup",
            OpKind::Create => "create",
            OpKind::Mkdir => "mkdir",
            OpKind::Unlink => "unlink",
            OpKind::Rmdir => "rmdir",
            OpKind::Rename => "rename",
            OpKind::Symlink => "symlink",
            OpKind::Link => "link",
            OpKind::Mknod => "mknod",
            OpKind::Open => "open",
            OpKind::Read => "read",
            OpKind::Write => "write",
            OpKind::Setattr => "setattr",
            OpKind::Fallocate => "fallocate",
            OpKind::Opendir => "opendir",
            OpKind::Readlink => "readlink",
            OpKind::Setxattr => "setxattr",
            OpKind::Getxattr => "getxattr",
            OpKind::Listxattr => "listxattr",
            OpKind::Removexattr => "removexattr",
            OpKind::Copyfilerange => "copyfilerange",
            OpKind::Syncfs => "syncfs",
            OpKind::Fsync => "fsync",
            OpKind::Fsyncdir => "fsyncdir",
            OpKind::Tmpfile => "tmpfile",
            OpKind::Readdir => "readdir",
            OpKind::Other => "other",
        }
    }
}

/// Maximum bytes of a name stored inline in an AuditRecord.
/// Names longer than this are truncated; the original length is preserved in `name_len`.
const NAME_INLINE_MAX: usize = 64;

/// A single audit event. Fixed-size to avoid per-record heap allocation.
/// All allocation for serialization happens on the background writer thread.
pub struct AuditRecord {
    /// Monotonic nanoseconds since boot (CLOCK_MONOTONIC).
    pub timestamp_mono_ns: u64,
    /// Wall-clock Unix timestamp: seconds.
    pub timestamp_wall_s: i64,
    /// Wall-clock nanoseconds fraction.
    pub timestamp_wall_ns: u32,

    /// Guest process context.
    pub uid: u32,
    pub gid: u32,
    pub pid: u32,

    /// Operation kind.
    pub op: OpKind,

    /// Parent inode (0 if not applicable for this op).
    pub parent_inode: u64,
    /// Target/subject inode (0 if not applicable).
    pub target_inode: u64,

    /// Policy decision.
    pub allow: bool,
    /// errno on deny (0 on allow).
    pub errno: i32,
    /// Static reason string (points into static string table).
    pub reason: &'static str,

    /// First NAME_INLINE_MAX bytes of the leaf name (zero-padded).
    pub name: [u8; NAME_INLINE_MAX],
    /// Actual name length before truncation.
    pub name_len: u8,

    /// Filter check latency in nanoseconds (saturating at u32::MAX).
    pub latency_ns: u32,
}

impl AuditRecord {
    fn new_allow(ctx: &Context, op: OpKind, parent: u64, target: u64, latency_ns: u32) -> Self {
        let (wall_s, wall_ns) = wall_time();
        AuditRecord {
            timestamp_mono_ns: mono_time_ns(),
            timestamp_wall_s: wall_s,
            timestamp_wall_ns: wall_ns,
            uid: ctx.uid.into_inner(),
            gid: ctx.gid.into_inner(),
            pid: ctx.pid as u32,
            op,
            parent_inode: parent,
            target_inode: target,
            allow: true,
            errno: 0,
            reason: "",
            name: [0u8; NAME_INLINE_MAX],
            name_len: 0,
            latency_ns,
        }
    }

    fn new_deny(
        ctx: &Context,
        op: OpKind,
        parent: u64,
        target: u64,
        errno: i32,
        reason: &'static str,
        latency_ns: u32,
    ) -> Self {
        let (wall_s, wall_ns) = wall_time();
        AuditRecord {
            timestamp_mono_ns: mono_time_ns(),
            timestamp_wall_s: wall_s,
            timestamp_wall_ns: wall_ns,
            uid: ctx.uid.into_inner(),
            gid: ctx.gid.into_inner(),
            pid: ctx.pid as u32,
            op,
            parent_inode: parent,
            target_inode: target,
            allow: false,
            errno,
            reason,
            name: [0u8; NAME_INLINE_MAX],
            name_len: 0,
            latency_ns,
        }
    }

    /// Copy the first NAME_INLINE_MAX bytes of `name` into the record.
    fn set_name(&mut self, name: &[u8]) {
        let copy_len = name.len().min(NAME_INLINE_MAX);
        self.name[..copy_len].copy_from_slice(&name[..copy_len]);
        self.name_len = name.len().min(255) as u8;
    }

    /// Serialize to a JSON-Lines string (one line per record).
    fn to_json_line(&self) -> String {
        // Inline name: strip trailing NUL padding, then escape for JSON.
        let name_bytes = &self.name[..self.name_len.min(NAME_INLINE_MAX as u8) as usize];
        let name_str = String::from_utf8_lossy(name_bytes);

        // Wall-clock ISO-8601 approximation: seconds + nanoseconds.
        let decision = if self.allow { "allow" } else { "deny" };

        if self.allow {
            format!(
                "{{\"ts_wall_s\":{},\"ts_wall_ns\":{},\"mono_ns\":{},\"op\":\"{}\",\
                 \"uid\":{},\"gid\":{},\"pid\":{},\"parent_inode\":{},\"target_inode\":{},\
                 \"decision\":\"{}\",\"latency_ns\":{},\"name\":\"{}\"}}\n",
                self.timestamp_wall_s,
                self.timestamp_wall_ns,
                self.timestamp_mono_ns,
                self.op.as_str(),
                self.uid,
                self.gid,
                self.pid,
                self.parent_inode,
                self.target_inode,
                decision,
                self.latency_ns,
                json_escape(&name_str),
            )
        } else {
            format!(
                "{{\"ts_wall_s\":{},\"ts_wall_ns\":{},\"mono_ns\":{},\"op\":\"{}\",\
                 \"uid\":{},\"gid\":{},\"pid\":{},\"parent_inode\":{},\"target_inode\":{},\
                 \"decision\":\"{}\",\"errno\":{},\"reason\":\"{}\",\
                 \"latency_ns\":{},\"name\":\"{}\"}}\n",
                self.timestamp_wall_s,
                self.timestamp_wall_ns,
                self.timestamp_mono_ns,
                self.op.as_str(),
                self.uid,
                self.gid,
                self.pid,
                self.parent_inode,
                self.target_inode,
                decision,
                self.errno,
                self.reason,
                self.latency_ns,
                json_escape(&name_str),
            )
        }
    }
}

/// Escape a string for use inside a JSON string literal. The name comes from
/// the guest, so quotes, backslashes and every control character are escaped;
/// a guest cannot break out of the field or inject a line into the log.
fn json_escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 8);
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 || c as u32 == 0x7f => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out
}

// ─── AuditLogger ─────────────────────────────────────────────────────────────

/// Non-blocking audit logger backed by a bounded MPSC channel.
/// A background thread drains the channel and writes JSON-Lines to the configured output.
#[derive(Clone)]
pub struct AuditLogger {
    level: AuditLevel,
    sender: Option<SyncSender<AuditRecord>>,
    dropped: Arc<AtomicU64>,
    /// Output errors seen by the writer thread (write or flush failures).
    write_errors: Arc<AtomicU64>,
}

impl AuditLogger {
    /// Create a disabled AuditLogger that performs no logging, allocates no channels,
    /// and spawns no background threads.
    pub fn disabled() -> Self {
        AuditLogger {
            level: AuditLevel::None,
            sender: None,
            dropped: Arc::new(AtomicU64::new(0)),
            write_errors: Arc::new(AtomicU64::new(0)),
        }
    }

    /// Create a new AuditLogger from config. Spawns the background writer thread.
    pub fn new(cfg: &AuditConfig) -> std::io::Result<Self> {
        if !cfg.enabled || cfg.level == AuditLevel::None {
            return Ok(Self::disabled());
        }

        // Open output before spawning thread so we return an error immediately if it fails.
        let writer: Box<dyn Write + Send> = match cfg.destination {
            AuditDestination::File => {
                let file = OpenOptions::new().create(true).append(true).open(&cfg.path)?;
                Box::new(BufWriter::with_capacity(65536, file))
            }
            AuditDestination::Stderr => Box::new(BufWriter::with_capacity(65536, std::io::stderr())),
        };
        Ok(Self::with_writer(cfg.level, cfg.channel_capacity, writer))
    }

    /// Build a logger over an arbitrary writer. Spawns the background writer thread.
    pub(crate) fn with_writer(level: AuditLevel, capacity: usize, writer: Box<dyn Write + Send>) -> Self {
        let (tx, rx): (SyncSender<AuditRecord>, Receiver<AuditRecord>) = sync_channel(capacity);
        let dropped = Arc::new(AtomicU64::new(0));
        let write_errors = Arc::new(AtomicU64::new(0));
        spawn_writer_thread(rx, dropped.clone(), write_errors.clone(), writer);
        AuditLogger {
            level,
            sender: Some(tx),
            dropped,
            write_errors,
        }
    }

    /// Send an audit record for a verdict. Non-blocking; drops on full channel.
    /// Does nothing if level==None or if the verdict is Allow and level==Deny.
    pub fn log(
        &self,
        ctx: &Context,
        op: OpKind,
        parent_inode: u64,
        target_inode: u64,
        name: &[u8],
        verdict: &Verdict,
        latency_ns: u32,
    ) {
        let sender = match &self.sender {
            Some(s) => s,
            None => return,
        };

        let is_deny = verdict.is_deny();

        // Level filter: only send deny events when level == Deny.
        match self.level {
            AuditLevel::None => return,
            AuditLevel::Deny if !is_deny => return,
            _ => {}
        }

        let mut record = match verdict {
            Verdict::Allow => AuditRecord::new_allow(ctx, op, parent_inode, target_inode, latency_ns),
            Verdict::Deny { errno, reason } => {
                AuditRecord::new_deny(ctx, op, parent_inode, target_inode, *errno, reason, latency_ns)
            }
        };
        record.set_name(name);

        match sender.try_send(record) {
            Ok(()) => {}
            Err(TrySendError::Full(_)) => {
                self.dropped.fetch_add(1, Ordering::Relaxed);
            }
            Err(TrySendError::Disconnected(_)) => {
                // Background thread has exited; ignore silently.
            }
        }
    }

    /// Start a latency measurement only when this logger can emit a record for
    /// an allowed request (level All). At level Deny and None the clock is not
    /// read on the request path at all; a denial record then carries
    /// `latency_ns = 0`, and its timestamps are still taken when it is built.
    #[inline(always)]
    pub fn clock(&self) -> Option<std::time::Instant> {
        // The `always-clock` feature restores the earlier behaviour (one clock
        // read per request) so that benches can measure what the gate saves.
        if cfg!(feature = "always-clock") || (self.sender.is_some() && self.level == AuditLevel::All) {
            Some(std::time::Instant::now())
        } else {
            None
        }
    }

    /// Dropped audit events so far, without resetting the counter.
    pub fn dropped_count(&self) -> u64 {
        self.dropped.load(Ordering::Relaxed)
    }

    /// Output errors (failed writes or flushes) seen by the writer thread.
    /// The writer stops after the first one, so later records are lost.
    pub fn write_error_count(&self) -> u64 {
        self.write_errors.load(Ordering::Relaxed)
    }

    /// Returns the number of dropped audit events since last call (resets counter).
    pub fn take_dropped_count(&self) -> u64 {
        self.dropped.swap(0, Ordering::Relaxed)
    }
}

// ─── Background writer thread ─────────────────────────────────────────────────

fn spawn_writer_thread(
    rx: Receiver<AuditRecord>,
    dropped: Arc<AtomicU64>,
    write_errors: Arc<AtomicU64>,
    mut writer: Box<dyn Write + Send>,
) {
    // An output error is counted, reported once on stderr, and ends the
    // writer: a sink that fails once is not retried, and the request path
    // is never blocked by it.
    let fail = move |errors: &AtomicU64, e: std::io::Error| {
        errors.fetch_add(1, Ordering::Relaxed);
        eprintln!("vfsd-filter: audit output error: {e}");
    };
    std::thread::Builder::new()
        .name("vfsd-audit-writer".to_string())
        .spawn(move || {
            loop {
                match rx.recv_timeout(Duration::from_millis(200)) {
                    Ok(record) => {
                        let line = record.to_json_line();
                        if let Err(e) = writer.write_all(line.as_bytes()) {
                            fail(&write_errors, e);
                            break;
                        }
                    }
                    Err(std::sync::mpsc::RecvTimeoutError::Timeout) => {
                        // Periodic flush.
                        if let Err(e) = writer.flush() {
                            fail(&write_errors, e);
                            break;
                        }
                        // Emit dropped-events line if any events were dropped since last flush.
                        let d = dropped.swap(0, Ordering::Relaxed);
                        if d > 0 {
                            let line = format!(
                                "{{\"event\":\"audit_dropped\",\"count\":{}}}\n",
                                d
                            );
                            let r = writer.write_all(line.as_bytes()).and_then(|_| writer.flush());
                            if let Err(e) = r {
                                fail(&write_errors, e);
                                break;
                            }
                        }
                    }
                    Err(std::sync::mpsc::RecvTimeoutError::Disconnected) => {
                        // Sender dropped; flush and exit.
                        if let Err(e) = writer.flush() {
                            fail(&write_errors, e);
                        }
                        break;
                    }
                }
            }
        })
        .expect("failed to spawn audit writer thread");
}

// ─── Timing helpers ──────────────────────────────────────────────────────────

fn mono_time_ns() -> u64 {
    let mut ts = libc::timespec {
        tv_sec: 0,
        tv_nsec: 0,
    };
    // SAFETY: ts is a valid, writable timespec; CLOCK_MONOTONIC is a valid clock ID.
    unsafe {
        libc::clock_gettime(libc::CLOCK_MONOTONIC, &mut ts);
    }
    (ts.tv_sec as u64)
        .wrapping_mul(1_000_000_000)
        .wrapping_add(ts.tv_nsec as u64)
}

fn wall_time() -> (i64, u32) {
    match SystemTime::now().duration_since(UNIX_EPOCH) {
        Ok(d) => (d.as_secs() as i64, d.subsec_nanos()),
        Err(_) => (0, 0),
    }
}

// ─── Tests ───────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::filter::config::{AuditConfig, AuditDestination, AuditLevel};
    use crate::filter::policy::Verdict;
    use virtiofsd::soft_idmap::{GuestGid, GuestUid};

    fn test_ctx() -> Context {
        Context {
            uid: GuestUid::from(1000u32),
            gid: GuestGid::from(1000u32),
            pid: 5678,
        }
    }

    fn disabled_logger() -> AuditLogger {
        let cfg = AuditConfig {
            enabled: false,
            level: AuditLevel::None,
            ..AuditConfig::default()
        };
        AuditLogger::new(&cfg).unwrap()
    }

    fn stderr_logger(level: AuditLevel) -> AuditLogger {
        let cfg = AuditConfig {
            enabled: true,
            destination: AuditDestination::Stderr,
            level,
            channel_capacity: 64,
            ..AuditConfig::default()
        };
        AuditLogger::new(&cfg).unwrap()
    }

    #[test]
    fn test_level_none_sender_is_none() {
        let logger = disabled_logger();
        assert!(logger.sender.is_none());
    }

    #[test]
    fn test_level_deny_allow_not_sent() {
        let logger = stderr_logger(AuditLevel::Deny);
        let ctx = test_ctx();
        // This should not panic or block, and should not send (level=Deny, verdict=Allow).
        logger.log(&ctx, OpKind::Read, 0, 123, b"", &Verdict::Allow, 100);
        // If we reach here without panic, the test passes.
    }

    #[test]
    fn test_level_all_allow_sent() {
        let logger = stderr_logger(AuditLevel::All);
        let ctx = test_ctx();
        // Should send without panic.
        logger.log(&ctx, OpKind::Read, 0, 123, b"file.txt", &Verdict::Allow, 100);
    }

    #[test]
    fn test_deny_sent_on_level_deny() {
        let logger = stderr_logger(AuditLevel::Deny);
        let ctx = test_ctx();
        let verdict = Verdict::Deny {
            errno: libc::EPERM,
            reason: "test deny",
        };
        // Should send without panic.
        logger.log(&ctx, OpKind::Unlink, 1, 0, b"shadow", &verdict, 200);
    }

    #[test]
    fn test_channel_full_increments_dropped() {
        // Very small channel to force drops.
        let cfg = AuditConfig {
            enabled: true,
            destination: AuditDestination::Stderr,
            level: AuditLevel::All,
            channel_capacity: 64, // minimum
            ..AuditConfig::default()
        };
        let logger = AuditLogger::new(&cfg).unwrap();
        let ctx = test_ctx();
        // Send many events without draining.
        // Note: background thread will drain some, so we can't guarantee exact drop count,
        // but we can verify dropped counter is accessible without panic.
        for _ in 0..200 {
            logger.log(&ctx, OpKind::Write, 0, 1, b"f", &Verdict::Allow, 50);
        }
        // Check counter is accessible (may be 0 if thread drained fast enough).
        let _dropped = logger.take_dropped_count();
    }

    #[test]
    fn test_record_json_allow() {
        let ctx = test_ctx();
        let mut r = AuditRecord::new_allow(&ctx, OpKind::Read, 5, 10, 123);
        r.set_name(b"file.txt");
        let json = r.to_json_line();
        assert!(json.contains("\"op\":\"read\""));
        assert!(json.contains("\"decision\":\"allow\""));
        assert!(json.contains("\"name\":\"file.txt\""));
        assert!(json.ends_with('\n'));
    }

    #[test]
    fn test_record_json_deny() {
        let ctx = test_ctx();
        let mut r = AuditRecord::new_deny(&ctx, OpKind::Unlink, 1, 0, libc::EPERM, "test reason", 456);
        r.set_name(b"shadow");
        let json = r.to_json_line();
        assert!(json.contains("\"op\":\"unlink\""));
        assert!(json.contains("\"decision\":\"deny\""));
        assert!(json.contains("\"reason\":\"test reason\""));
        assert!(json.contains("\"name\":\"shadow\""));
    }

    #[test]
    fn test_record_json_escapes_name_control_chars() {
        let ctx = test_ctx();
        let mut r = AuditRecord::new_deny(&ctx, OpKind::Create, 1, 0, libc::EACCES, "test reason", 1);
        r.set_name(b"a\"b\\c\nd\te\x01f\x7f");
        let json = r.to_json_line();
        assert!(json.contains("\"name\":\"a\\\"b\\\\c\\nd\\te\\u0001f\\u007f\""), "{json}");
        // One record stays one line: the only newline is the terminator.
        assert_eq!(json.matches('\n').count(), 1);
        assert!(json.ends_with('\n'));
    }

    #[test]
    fn test_writer_errors_are_counted() {
        struct FailingWriter;
        impl Write for FailingWriter {
            fn write(&mut self, _buf: &[u8]) -> std::io::Result<usize> {
                Err(std::io::Error::other("simulated audit output failure"))
            }
            fn flush(&mut self) -> std::io::Result<()> {
                Ok(())
            }
        }
        let logger = AuditLogger::with_writer(AuditLevel::Deny, 64, Box::new(FailingWriter));
        let ctx = test_ctx();
        let verdict = Verdict::Deny { errno: libc::EPERM, reason: "test deny" };
        assert_eq!(logger.write_error_count(), 0);
        logger.log(&ctx, OpKind::Unlink, 1, 0, b"shadow", &verdict, 0);
        let deadline = std::time::Instant::now() + Duration::from_secs(3);
        while logger.write_error_count() == 0 && std::time::Instant::now() < deadline {
            std::thread::sleep(Duration::from_millis(10));
        }
        assert_eq!(logger.write_error_count(), 1);
        // The writer has stopped; logging must still return at once.
        for _ in 0..200 {
            logger.log(&ctx, OpKind::Unlink, 1, 0, b"shadow", &verdict, 0);
        }
        assert_eq!(logger.write_error_count(), 1);
    }

    #[test]
    fn test_name_truncation_at_64() {
        let ctx = test_ctx();
        let mut r = AuditRecord::new_allow(&ctx, OpKind::Lookup, 1, 0, 100);
        let long_name: Vec<u8> = b"a".repeat(100);
        r.set_name(&long_name);
        // name_len is capped at 255 (u8 max) but actual stored length is capped at NAME_INLINE_MAX.
        assert_eq!(r.name_len, 100); // actual length stored
        // First 64 bytes of name are stored.
        assert_eq!(&r.name[..64], b"a".repeat(64).as_slice());
    }

    #[test]
    fn test_contains_dotdot_component() {
        use super::super::policy::contains_dotdot_component;
        assert!(contains_dotdot_component(b"../escape"));
        assert!(contains_dotdot_component(b"foo/../bar"));
        assert!(contains_dotdot_component(b"foo/.."));
        assert!(!contains_dotdot_component(b"foo/bar"));
        assert!(!contains_dotdot_component(b"a..b"));
        assert!(!contains_dotdot_component(b"notdotdot"));
    }
}
