// SPDX-License-Identifier: Apache-2.0
//
// Measures what the audit logger adds to a process's virtual size (VmSize)
// and lists the mappings it creates. Run:  cargo run --release --example vsz_probe

use std::collections::BTreeSet;
use std::path::PathBuf;
use std::time::Duration;

use vfsd_filter::filter::audit::{AuditLogger, OpKind};
use vfsd_filter::filter::config::{AuditConfig, AuditDestination, AuditLevel, FilterConfig};
use vfsd_filter::filter::policy::Verdict;
use virtiofsd::filesystem::Context;

fn status_kib(key: &str) -> u64 {
    std::fs::read_to_string("/proc/self/status")
        .unwrap()
        .lines()
        .find(|l| l.starts_with(key))
        .and_then(|l| l.split_whitespace().nth(1))
        .and_then(|v| v.parse().ok())
        .unwrap()
}

/// (start, end, perms, name) for every mapping.
fn maps() -> BTreeSet<(u64, u64, String, String)> {
    std::fs::read_to_string("/proc/self/maps")
        .unwrap()
        .lines()
        .map(|l| {
            let mut it = l.split_whitespace();
            let range = it.next().unwrap();
            let perms = it.next().unwrap().to_owned();
            let name = it.nth(3).unwrap_or("[anon]").to_owned();
            let (a, b) = range.split_once('-').unwrap();
            (u64::from_str_radix(a, 16).unwrap(), u64::from_str_radix(b, 16).unwrap(), perms, name)
        })
        .collect()
}

fn report(label: &str, base_vsz: u64, base_rss: u64, before: &BTreeSet<(u64, u64, String, String)>) {
    let vsz = status_kib("VmSize:");
    let rss = status_kib("VmRSS:");
    println!("{label}: VmSize {vsz} KiB (+{}), VmRSS {rss} KiB (+{})", vsz - base_vsz, rss.saturating_sub(base_rss));
    for (a, b, perms, name) in maps().difference(before) {
        println!("    new mapping {:>8} KiB {perms} {name}", (b - a) / 1024);
    }
}

fn main() {
    let base_vsz = status_kib("VmSize:");
    let base_rss = status_kib("VmRSS:");
    let before = maps();
    println!("baseline: VmSize {base_vsz} KiB, VmRSS {base_rss} KiB");

    let mut cfg: AuditConfig = FilterConfig::default().audit;
    cfg.enabled = true;
    cfg.level = AuditLevel::Deny;
    cfg.destination = AuditDestination::File;
    cfg.path = PathBuf::from("/dev/null");
    cfg.channel_capacity = 4096;
    let logger = AuditLogger::new(&cfg).unwrap();
    std::thread::sleep(Duration::from_millis(200));
    report("after AuditLogger::new (capacity 4096)", base_vsz, base_rss, &before);

    let ctx = Context { uid: 0.into(), gid: 0.into(), pid: 1 };
    let deny = Verdict::Deny { errno: libc::EACCES, reason: "probe" };
    for _ in 0..100 {
        logger.log(&ctx, OpKind::Create, 1, 0, b"probe.pem", &deny, 0);
    }
    std::thread::sleep(Duration::from_millis(500));
    report("after 100 denial records written", base_vsz, base_rss, &before);
}
