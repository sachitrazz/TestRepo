// SPDX-License-Identifier: Apache-2.0
//
// False positive check on real directory trees.
//
// Walks a real directory tree and recreates every directory, file and symlink
// (with its real name and real link target) inside a temporary share through
// FilteredFs<PassthroughFs>, the way a package install or a checkout would:
// one lookup, then one mkdir, mknod or symlink per entry. The policy is the
// one in Listing 2 of the paper. Every denial is tallied by the rule that
// fired.
//
// Run:  cargo run --release --example replay_tree -- /etc /usr/lib

use std::collections::BTreeMap;
use std::ffi::CString;
use std::fs;
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::PermissionsExt;
use std::path::Path;

use vfsd_filter::filter::config::FilterConfig;
use vfsd_filter::filter::policy::{PolicyEngine, Verdict, OP_CREATE, OP_SYMLINK};
use vfsd_filter::filter::FilteredFs;
use virtiofsd::filesystem::{Context, Extensions, FileSystem, FsOptions};
use virtiofsd::fuse::ROOT_ID;
use virtiofsd::passthrough::{self, PassthroughFs};

fn ctx() -> Context {
    Context { uid: 0.into(), gid: 0.into(), pid: std::process::id() as i32 }
}

fn listing2_policy() -> FilterConfig {
    let mut cfg = FilterConfig::default();
    cfg.names.deny_suffixes = vec![".filter-test".into(), ".key".into(), ".pem".into()];
    cfg.names.deny_prefixes = vec![".ssh".into()];
    cfg.names.deny_exact = vec!["shadow".into()];
    cfg.paths.deny_root_children = vec!["etc".into()];
    cfg.symlink.allow_absolute_targets = false;
    cfg.symlink.allow_dotdot_targets = false;
    cfg.audit.enabled = false;
    cfg
}

#[derive(Default)]
struct Tally {
    dirs: u64,
    files: u64,
    symlinks: u64,
    lookups: u64,
    lookup_denied: u64,
    allowed: u64,
    denied: BTreeMap<&'static str, u64>,
    denied_symlink_abs_examples: Vec<String>,
    skipped_under_denied_dir: u64,
    unreadable: u64,
    mismatch: u64,
    inner_errors: u64,
}

struct Replay<'a> {
    fs: &'a FilteredFs<PassthroughFs>,
    engine: &'a PolicyEngine,
    t: Tally,
}

fn count_entries(p: &Path) -> u64 {
    let mut n = 0;
    if let Ok(rd) = fs::read_dir(p) {
        for e in rd.flatten() {
            n += 1;
            if e.file_type().map(|t| t.is_dir()).unwrap_or(false) {
                n += count_entries(&e.path());
            }
        }
    }
    n
}

impl Replay<'_> {
    fn record(&mut self, verdict: Verdict, result_ok: bool, errno: Option<i32>) -> bool {
        match verdict {
            Verdict::Allow => {
                if result_ok {
                    self.t.allowed += 1;
                } else {
                    self.t.inner_errors += 1;
                }
                result_ok
            }
            Verdict::Deny { errno: want, reason } => {
                *self.t.denied.entry(reason).or_default() += 1;
                if result_ok || errno != Some(want) {
                    self.t.mismatch += 1;
                }
                false
            }
        }
    }

    fn walk(&mut self, src: &Path, parent: u64) {
        let rd = match fs::read_dir(src) {
            Ok(rd) => rd,
            Err(_) => {
                self.t.unreadable += 1;
                return;
            }
        };
        let mut entries: Vec<_> = rd.flatten().collect();
        entries.sort_by_key(|e| e.file_name());
        for e in entries {
            let name_os = e.file_name();
            let name_b = name_os.as_bytes();
            let name = match CString::new(name_b) {
                Ok(n) => n,
                Err(_) => continue,
            };
            let ft = match e.file_type() {
                Ok(ft) => ft,
                Err(_) => {
                    self.t.unreadable += 1;
                    continue;
                }
            };
            let mode = e.metadata().map(|m| m.permissions().mode()).unwrap_or(0o644);

            // A client looks the name up before creating it.
            self.t.lookups += 1;
            if self.engine.check_lookup(parent, name_b).is_deny() {
                self.t.lookup_denied += 1;
            }
            if let Ok(entry) = self.fs.lookup(ctx(), parent, &name) {
                self.fs.forget(ctx(), entry.inode, 1);
            }

            if ft.is_dir() {
                self.t.dirs += 1;
                let v = self.engine.check_name_op(OP_CREATE, parent, name_b);
                let r = self.fs.mkdir(ctx(), parent, &name, mode & 0o7777, 0, Extensions::default());
                let errno = r.as_ref().err().and_then(|e| e.raw_os_error());
                let inode = r.as_ref().ok().map(|en| en.inode);
                if self.record(v, r.is_ok(), errno) {
                    let inode = inode.unwrap();
                    self.walk(&e.path(), inode);
                    self.fs.forget(ctx(), inode, 1);
                } else {
                    self.t.skipped_under_denied_dir += count_entries(&e.path());
                }
            } else if ft.is_symlink() {
                self.t.symlinks += 1;
                let target = match fs::read_link(e.path()) {
                    Ok(t) => t,
                    Err(_) => {
                        self.t.unreadable += 1;
                        continue;
                    }
                };
                let target_b = target.as_os_str().as_bytes();
                let target_c = match CString::new(target_b) {
                    Ok(t) => t,
                    Err(_) => continue,
                };
                let v = self.engine.check_symlink(parent, name_b, target_b);
                if let Verdict::Deny { reason, .. } = &v {
                    if reason.contains("absolute") && self.t.denied_symlink_abs_examples.len() < 5 {
                        self.t.denied_symlink_abs_examples.push(format!("{} -> {}", e.path().display(), target.display()));
                    }
                }
                let r = self.fs.symlink(ctx(), &target_c, parent, &name, Extensions::default());
                let errno = r.as_ref().err().and_then(|e| e.raw_os_error());
                if let Ok(en) = &r {
                    self.fs.forget(ctx(), en.inode, 1);
                }
                self.record(v, r.is_ok(), errno);
            } else if ft.is_file() {
                self.t.files += 1;
                let v = self.engine.check_name_op(OP_CREATE, parent, name_b);
                let r = self.fs.mknod(ctx(), parent, &name, libc::S_IFREG | (mode & 0o777), 0, 0, Extensions::default());
                let errno = r.as_ref().err().and_then(|e| e.raw_os_error());
                if let Ok(en) = &r {
                    self.fs.forget(ctx(), en.inode, 1);
                }
                self.record(v, r.is_ok(), errno);
            }
        }
    }
}

fn main() {
    let _ = OP_SYMLINK;
    for src in std::env::args().skip(1) {
        let base = std::env::temp_dir().join(format!("vfsd-replay-{}", std::process::id()));
        let share = base.join("share");
        let _ = fs::remove_dir_all(&base);
        fs::create_dir_all(&share).unwrap();
        let cfg = listing2_policy();
        let pcfg = passthrough::Config { root_dir: share.to_str().unwrap().to_owned(), ..Default::default() };
        let inner = PassthroughFs::new(pcfg).unwrap();
        inner.init(FsOptions::empty()).unwrap();
        let ffs = FilteredFs::from_config(inner, &cfg).unwrap();
        let engine = PolicyEngine::from_config(&cfg);
        let mut r = Replay { fs: &ffs, engine: &engine, t: Tally::default() };
        r.walk(Path::new(&src), ROOT_ID);
        let t = r.t;
        let denied_total: u64 = t.denied.values().sum();
        println!("TREE {src}");
        println!("  entries: dirs={} files={} symlinks={} total={}", t.dirs, t.files, t.symlinks, t.dirs + t.files + t.symlinks);
        println!("  lookups: {} issued, {} denied", t.lookups, t.lookup_denied);
        println!("  create operations: allowed={} denied={} inner_errors={} verdict_mismatches={}", t.allowed, denied_total, t.inner_errors, t.mismatch);
        for (reason, n) in &t.denied {
            println!("    denied by \"{reason}\": {n}");
        }
        for ex in &t.denied_symlink_abs_examples {
            println!("    example absolute target: {ex}");
        }
        println!("  not replayed: {} entries under denied directories, {} unreadable", t.skipped_under_denied_dir, t.unreadable);
        let _ = fs::remove_dir_all(&base);
    }
}
